Malak 0.1 - Simple AI Chat Bot

How to run:
1. Extract the ZIP file.
2. Run "Malak_0.1.exe" to start the chat.
3. Windows may show a security warning since the app is not signed. Click "More info" > "Run anyway".

Features:
- Simple AI chat bot
- User-friendly interface
- Chat bubbles with colors
- Fun AI personality